import { DEMO_BILL_ITEMS, DEMO_INSURANCE_PLANS } from './demo-data'
import type { BillItem, ReviewRequest, ReviewResult, ReviewSummary } from './types'

/** How long the simulated analysis takes, in milliseconds. */
export const SIMULATED_REVIEW_DURATION_MS = 4800

export const ACCEPTED_FILE_TYPES = [
  'application/pdf',
  'text/csv',
  'image/png',
  'image/jpeg',
  'image/webp',
  'image/heic',
]
export const ACCEPTED_FILE_EXTENSIONS = ['.pdf', '.csv', '.png', '.jpg', '.jpeg', '.webp', '.heic']
export const MAX_FILE_SIZE_MB = 10

export function isAcceptedFile(file: File) {
  const name = file.name.toLowerCase()
  return (
    ACCEPTED_FILE_TYPES.includes(file.type) ||
    ACCEPTED_FILE_EXTENSIONS.some((extension) => name.endsWith(extension))
  )
}

export function summarizeItems(items: BillItem[]): ReviewSummary {
  return items.reduce<ReviewSummary>(
    (summary, item) => {
      summary.totalBilled += item.billedAmount
      if (item.status === 'needs_review') {
        summary.issuesFound += 1
        if (item.referenceAmount !== null && item.billedAmount > item.referenceAmount) {
          summary.potentialSavings += item.billedAmount - item.referenceAmount
        }
      }
      return summary
    },
    { totalBilled: 0, potentialSavings: 0, issuesFound: 0 },
  )
}

/**
 * SIMULATED DEMO BEHAVIOUR.
 *
 * This function does not read the uploaded files. It waits for a short delay
 * and returns fictional sample results so the interface can be demonstrated.
 *
 * To connect a real Python backend later, replace the body with something like:
 *
 *   const formData = new FormData()
 *   formData.append('plan_id', request.planId)
 *   formData.append('bill', request.billFile)
 *   formData.append('visit_summary', request.visitSummaryFile)
 *   const response = await fetch('/api/review', { method: 'POST', body: formData })
 *   if (!response.ok) throw new Error('Review failed')
 *   return (await response.json()) as ReviewResult
 */
export async function reviewBill(request: ReviewRequest): Promise<ReviewResult> {
  await new Promise((resolve) => setTimeout(resolve, SIMULATED_REVIEW_DURATION_MS))

  const plan = DEMO_INSURANCE_PLANS.find((option) => option.id === request.planId)

  return {
    isDemo: true,
    planName: plan?.name ?? 'Selected plan',
    summary: summarizeItems(DEMO_BILL_ITEMS),
    items: DEMO_BILL_ITEMS,
  }
}
